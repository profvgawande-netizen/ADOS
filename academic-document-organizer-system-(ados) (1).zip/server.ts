import 'dotenv/config';
import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import fs from "fs";
import { getDb } from "./src/db/index.js";
import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import multer from "multer";
import { format, addDays } from "date-fns";
import { createRequire } from "module";
const require = createRequire(import.meta.url);

const app = express();
const PORT = 3000;
const SECRET_KEY = process.env.SECRET_KEY || "your_jwt_secret_key_12345";

app.use(express.json());

// Setup storage directory
const storageDir = path.resolve(process.cwd(), "app/storage");
if (!fs.existsSync(storageDir)) {
  fs.mkdirSync(storageDir, { recursive: true });
}

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, storageDir),
  filename: (req, file, cb) => cb(null, `${Date.now()}_${file.originalname}`)
});
const upload = multer({ storage });

// Verification Middleware - BYPASSED for testing
const authenticateToken = (req: any, res: any, next: any) => {
  req.user = { id: 'test-admin-id', email: 'admin@ados.edu', role: '1' };
  next();
};

// --- API ROUTES ---

// Health check
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

// Auth - BYPASSED logic, but kept for compatibility
app.post("/api/v1/auth/login", async (req, res) => {
  const { email } = req.body;
  const token = jwt.sign({ id: 'test-admin-id', email: email || 'admin@ados.edu', role: '1' }, SECRET_KEY, { expiresIn: '7d' });
  res.json({ 
    access_token: token, 
    user: { 
      id: 'test-admin-id', 
      name: "Test Admin", 
      email: email || 'admin@ados.edu', 
      role: '1' 
    } 
  });
});

// User profile
app.get("/api/v1/users/me", authenticateToken, async (req: any, res) => {
  const db = await getDb();
  const userDoc = await db.collection('users').doc(req.user.id).get();
  if (!userDoc.exists) return res.status(404).send("User not found");
  
  res.json({ id: userDoc.id, ...userDoc.data() });
});

// Courses
app.get("/api/v1/courses", authenticateToken, async (req, res) => {
  try {
    const db = await getDb();
    const snapshot = await db.collection('courses').get();
    const courses = snapshot?.docs?.map((doc: any) => ({ id: doc.id, ...doc.data() })) || [];
    res.json({ data: courses });
  } catch (err: any) {
    console.error("GET courses failed:", err.message);
    res.json({ data: [] });
  }
});

app.post("/api/v1/courses", authenticateToken, async (req, res) => {
  try {
    const { semester_id, course_code, course_name, credits, hours_per_week, course_type } = req.body;
    const db = await getDb();
    const result = await db.collection('courses').add({
      semester_id,
      course_code,
      course_name,
      credits: Number(credits),
      hours_per_week: Number(hours_per_week),
      course_type,
      created_at: new Date().toISOString()
    });
    res.json({ message: "Course created successfully", course_id: result.id });
  } catch (err: any) {
    res.status(500).json({ message: err.message });
  }
});

// Topics
app.get("/api/v1/topics", authenticateToken, async (req, res) => {
  try {
    const { course_id } = req.query;
    const db = await getDb();
    
    let snapshot;
    if (course_id) {
       snapshot = await db.collection('courses').doc(String(course_id)).collection('topics').get();
    } else {
       snapshot = await db.collectionGroup('topics').get();
    }
    
    const topics = snapshot?.docs?.map((doc: any) => ({ id: doc.id, ...doc.data() })) || [];
    res.json({ data: topics });
  } catch (err: any) {
    res.json({ data: [] });
  }
});

// Get Context for Lesson Plan Generation
app.get("/api/v1/lesson-plans/prepare-context", authenticateToken, async (req: any, res) => {
  try {
    const { 
      course_id, 
      start_date, 
      end_date, 
      class_days,
      exclude_event_types,
      syllabus_doc_id,
      template_doc_id
    } = req.query;
    
    const db = await getDb();

    // 1. Get available dates from calendar
    const blockedDateSet = new Set<string>();
    try {
      const types = Array.isArray(exclude_event_types) 
        ? exclude_event_types 
        : (exclude_event_types ? [exclude_event_types] : []);

      let snapshot;
      
      // Fetch events that could potentially overlap with the date range
      // We fetch all and filter in memory for better overlap and type matching
      snapshot = await db.collection('calendar_events')
        .where('start_date', '<=', end_date)
        .get();

      snapshot.forEach((doc: any) => {
        const e = doc.data();
        const eventEnd = e.end_date || e.start_date;
        
        // Overlap check: event starts <= end_date AND event ends >= start_date
        if (eventEnd < start_date) return;

        // Type check: Only block if it matches selected types OR (if none selected) it is explicitly blocked
        const isExcludedType = types.length > 0 && types.includes(e.event_type);
        const isGenerallyBlocked = types.length === 0 && e.is_teaching_blocked === true;
        
        if (isExcludedType || isGenerallyBlocked) {
          let d = new Date(e.start_date);
          const endDay = new Date(eventEnd);
          while (d <= endDay) {
            blockedDateSet.add(format(d, 'yyyy-MM-dd'));
            d = addDays(d, 1);
          }
        }
      });
    } catch (err: any) {
      console.warn("ADOS: Calendar events fetch failed:", err.message);
    }

    const availableDates: { date: string, day: string }[] = [];
    let current = new Date(start_date as string);
    const endDateObj = new Date(end_date as string);
    const normalizedClassDays = (Array.isArray(class_days) ? class_days : [class_days]).map((d: any) => String(d).toLowerCase());

    while (current <= endDateObj) {
      const dayName = format(current, 'eeee').toLowerCase();
      const dateStr = format(current, 'yyyy-MM-dd');
      if (normalizedClassDays.includes(dayName) && !blockedDateSet.has(dateStr)) {
        availableDates.push({ date: dateStr, day: format(current, 'eeee') });
      }
      current = addDays(current, 1);
    }

    if (availableDates.length === 0) {
      return res.status(400).json({ message: "No available teaching slots found." });
    }

    // 2. Get document content
    const [syllabusDoc, templateDoc] = await Promise.all([
      db.collection('documents').doc(String(syllabus_doc_id)).get(),
      template_doc_id ? db.collection('documents').doc(String(template_doc_id)).get() : Promise.resolve(null)
    ]);

    const getDocContent = async (doc: any) => {
      if (!doc || !doc.exists) return "";
      const data = doc.data();
      const filePath = data.file_path;
      if (!fs.existsSync(filePath)) return "";
      
      if (data.mime_type === 'application/pdf') {
        try {
          const pdfParse = require('pdf-parse');
          let fn = pdfParse;
          if (typeof pdfParse !== 'function' && pdfParse.default) {
            fn = pdfParse.default;
          }
          if (typeof fn === 'function') {
            const buf = fs.readFileSync(filePath);
            const pdf = await fn(buf);
            return pdf.text;
          }
        } catch (e) {
          console.error("PDF parse failed:", e);
        }
      }
      return fs.readFileSync(filePath, 'utf-8');
    };

    const syllabusText = await getDocContent(syllabusDoc);
    const templateText = templateDoc ? await getDocContent(templateDoc) : "";
    const courseDoc = await db.collection('courses').doc(String(course_id)).get();

    res.json({
      availableDates,
      syllabusText,
      templateText,
      courseName: courseDoc.data()?.course_name || "Course"
    });
  } catch (err: any) {
    res.status(500).json({ message: err.message });
  }
});

// Finalize and Save Lesson Plan
app.post("/api/v1/lesson-plans/save", authenticateToken, async (req: any, res) => {
  try {
    const { course_id, start_date, end_date, items, title } = req.body;
    const db = await getDb();

    const planRef = db.collection('lesson_plans').doc();
    await planRef.set({
      course_id,
      faculty_id: req.user.id,
      start_date,
      end_date,
      status: 'draft',
      title: title || "Lesson Plan",
      created_at: new Date().toISOString()
    });

    const batch = db.batch();
    items.forEach((item: any) => {
      const itemRef = planRef.collection('items').doc();
      batch.set(itemRef, {
        ...item,
        status: 'planned'
      });
    });
    await batch.commit();

    const courseDoc = await db.collection('courses').doc(String(course_id)).get();
    res.json({
      lesson_plan_id: planRef.id,
      course_name: courseDoc.data()?.course_name || "Course",
      total_topics: items.length,
      status: "saved",
      items
    });
  } catch (err: any) {
    res.status(500).json({ message: err.message });
  }
});

// AI Content Generation (OBSOLETE: Moved to Frontend)
// Removed to follow skill guidelines - call AI from frontend instead.

// Document Upload
app.get("/api/v1/documents/:id/content", authenticateToken, async (req: any, res) => {
  try {
    const db = await getDb();
    const docInfo = await db.collection('documents').doc(req.params.id).get();
    if (!docInfo.exists) return res.status(404).json({ message: "Document not found" });
    
    const data = docInfo.data();
    const filePath = data.file_path;

    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ message: "File not found on server" });
    }

    if (data.mime_type === 'application/pdf') {
      try {
        const pdfParse = require('pdf-parse');
        if (typeof pdfParse !== 'function') {
          console.error("ADOS: pdf-parse is not a function. Type:", typeof pdfParse);
          const fn = pdfParse.default || pdfParse;
          if (typeof fn === 'function') {
            const dataBuffer = fs.readFileSync(filePath);
            const pdfData = await fn(dataBuffer);
            return res.json({ content: pdfData.text });
          }
          throw new Error(`PDF parser initialization failed - got ${typeof pdfParse}`);
        }
        
        const dataBuffer = fs.readFileSync(filePath);
        const pdfData = await pdfParse(dataBuffer);
        return res.json({ content: pdfData.text });
      } catch (pdfErr: any) {
        console.error("ADOS: PDF Parse error:", pdfErr.message);
        throw pdfErr;
      }
    } else {
      const content = fs.readFileSync(filePath, 'utf-8');
      return res.json({ content });
    }
  } catch (err: any) {
    console.error("Error reading document content:", err);
    res.status(500).json({ message: "Failed to read document content: " + err.message });
  }
});

app.post("/api/v1/documents/upload", authenticateToken, upload.single('file'), async (req: any, res) => {
  if (!req.file) return res.status(400).send('No file uploaded.');
  
  const db = await getDb();
  const { document_type } = req.body;
  
  const docRef = await db.collection('documents').add({
    uploaded_by: req.user.id,
    document_title: req.file.originalname,
    document_type,
    file_name: req.file.filename,
    file_path: req.file.path,
    mime_type: req.file.mimetype,
    file_size: req.file.size,
    created_at: new Date().toISOString()
  });

  res.json({ message: "File uploaded successfully", document_id: docRef.id });
});

app.get("/api/v1/documents", authenticateToken, async (req, res) => {
  try {
    const db = await getDb();
    const snapshot = await db.collection('documents').orderBy('created_at', 'desc').get();
    const docs = snapshot?.docs?.map((doc: any) => ({ id: doc.id, ...doc.data() })) || [];
    res.json({ data: docs });
  } catch (err: any) {
    res.json({ data: [] });
  }
});

app.delete("/api/v1/documents/:id", authenticateToken, async (req: any, res) => {
  try {
    const db = await getDb();
    const docRef = db.collection('documents').doc(req.params.id);
    const docSnap = await docRef.get();

    if (!docSnap.exists) {
      return res.status(404).json({ message: "Document not found" });
    }

    const data = docSnap.data();
    const filePath = data.file_path;

    // Remove from filesystem if exists
    if (filePath && fs.existsSync(filePath)) {
      try {
        fs.unlinkSync(filePath);
      } catch (fsErr: any) {
        console.error(`Failed to delete file at ${filePath}:`, fsErr.message);
      }
    }

    // Remove from Firestore
    await docRef.delete();

    res.json({ message: "Document deleted successfully" });
  } catch (err: any) {
    console.error("Delete document failed:", err.message);
    res.status(500).json({ message: "Failed to delete document" });
  }
});

// Approvals
app.post("/api/v1/approvals/:id/approve", authenticateToken, async (req: any, res) => {
  const db = await getDb();
  await db.collection('approvals').doc(req.params.id).update({ 
    status: 'Approved', 
    reviewed_at: new Date().toISOString() 
  });
  res.json({ message: "Approved successfully" });
});

app.post("/api/v1/approvals/:id/reject", authenticateToken, async (req: any, res) => {
  const db = await getDb();
  await db.collection('approvals').doc(req.params.id).update({ 
    status: 'Rejected', 
    reviewed_at: new Date().toISOString() 
  });
  res.json({ message: "Rejected successfully" });
});

app.get("/api/v1/approvals", authenticateToken, async (req: any, res) => {
  try {
    const db = await getDb();
    const snapshot = await db.collection('approvals').orderBy('submitted_at', 'desc').get();
    
    const approvals = [];
    if (snapshot?.docs) {
      for (const doc of snapshot.docs) {
        const data = doc.data();
        const docInfo = await db.collection('documents').doc(data.document_id).get();
        const userInfo = await db.collection('users').doc(data.submitted_by).get();
        approvals.push({
          id: doc.id,
          ...data,
          document_title: docInfo.data()?.document_title || "Unknown",
          submitted_by_name: userInfo.data()?.full_name || "Unknown"
        });
      }
    }
    res.json({ data: approvals });
  } catch (err: any) {
    res.json({ data: [] });
  }
});

// Reports
app.get("/api/v1/reports/faculty-workload", authenticateToken, async (req, res) => {
  const db = await getDb();
  const usersSnapshot = await db.collection('users').get();
  const data = [];
  for (const doc of usersSnapshot.docs) {
    const plansSnapshot = await db.collection('lesson_plans').where('faculty_id', '==', doc.id).get();
    data.push({
      full_name: doc.data().full_name,
      classes_count: plansSnapshot.size
    });
  }
  res.json({ data });
});

// Dashboard Stats
app.get("/api/v1/dashboard/stats", authenticateToken, async (req: any, res) => {
  try {
    const db = await getDb();
    const userId = req.user.id;

    // Use try/catch for each count to be resilient
    const getCount = async (coll: any) => {
      try {
        const snap = await coll.count().get();
        return snap.data().count;
      } catch {
        return 0;
      }
    };

    const stats = {
      total_courses: await getCount(db.collection('courses')),
      total_lesson_plans: await getCount(db.collection('lesson_plans').where('faculty_id', '==', userId)),
      pending_approvals: await getCount(db.collection('approvals').where('status', '==', 'Submitted')),
      ai_generated: await getCount(db.collection('ai_generated_content').where('user_id', '==', userId))
    };

    res.json(stats);
  } catch (err: any) {
    res.json({
      total_courses: 0,
      total_lesson_plans: 0,
      pending_approvals: 0,
      ai_generated: 0
    });
  }
});

// --- VITE MIDDLEWARE ---
async function startServer() {
  console.log("ADOS: Starting server initialization (Firestore Edition)...");
  
  // Initialize app first so it's ready even if DB fails
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  const server = app.listen(PORT, "0.0.0.0", () => {
    console.log(`ADOS: Server running on http://0.0.0.0:${PORT}`);
  });

  // Background Database Check/Seeding
  (async () => {
    try {
      const db = await getDb();
      console.log("ADOS: Database connection ready.");

      // 1. Ensure Admin User exists as requested
      const adminEmail = "admin@ados.edu";
      try {
        const adminUserSnapshot = await db.collection('users').where('email', '==', adminEmail).limit(1).get();
        if (adminUserSnapshot.empty) {
          console.log(`ADOS: Creating requested admin user: ${adminEmail}`);
          const hashedPassword = await bcrypt.hash("test123", 10);
          await db.collection('users').add({
            full_name: "System Administrator",
            email: adminEmail,
            password_hash: hashedPassword,
            role_id: "1", // Super Admin
            status: "active",
            created_at: new Date().toISOString()
          });
          console.log("ADOS: Admin user created.");
        }
      } catch (adminErr: any) {
        console.warn(`ADOS: Could not check/create admin user: ${adminErr.message}`);
      }

      // 2. Initial Data Seed - check and add multiple courses
      try {
        const targetCourses = [
          { code: "CS-401", name: "Theory of Computation", type: "Theory" },
          { code: "CS-402", name: "Software Engineering", type: "Theory" },
          { code: "CS-403", name: "Design and Analysis of Algorithms", type: "Theory" },
          { code: "CS-404", name: "Enterprise Programming using Java", type: "Lab" },
          { code: "CS-405", name: "Quant and Reasoning", type: "Theory" },
          { code: "CS-406", name: "Professionalism and Corporate Ethics", type: "Theory" }
        ];

        for (const target of targetCourses) {
          const snapshot = await db.collection('courses').where('course_name', '==', target.name).limit(1).get();
          if (snapshot.empty) {
            console.log(`ADOS: Seeding course: ${target.name}`);
            const courseRef = await db.collection('courses').add({
              course_code: target.code,
              course_name: target.name,
              credits: 4,
              hours_per_week: 4,
              course_type: target.type,
              created_at: new Date().toISOString()
            });

            // Add some default topics for each
            await courseRef.collection('topics').add({ topic_title: "Module 1: Introduction", sequence_no: 1, bloom_level: "Remember" });
            await courseRef.collection('topics').add({ topic_title: "Module 2: Core Concepts", sequence_no: 2, bloom_level: "Understand" });
            await courseRef.collection('topics').add({ topic_title: "Module 3: Advanced Topics", sequence_no: 3, bloom_level: "Analyze" });
          }
        }
        
        // Ensure some calendar events exist
        const holidaySnapshot = await db.collection('calendar_events').limit(1).get();
        if (holidaySnapshot.empty) {
          await db.collection('calendar_events').add({
            event_name: "Independence Day",
            event_type: "Holiday",
            start_date: "2026-08-15",
            end_date: "2026-08-15",
            is_teaching_blocked: true
          });
          console.log("ADOS: Basic calendar events seeded.");
        }
      } catch (seedErr: any) {
        console.error("ADOS: Seeding check/operation failed:", seedErr.message);
      }
    } catch (err) {
      console.error("ADOS: Non-fatal error during background database task:", err);
    }
  })();
}

startServer();
