# Security Specification - ADOS

## Data Invariants
1. A Lesson Plan must reference a valid Course ID.
2. A Lesson Plan Item must reference a valid Lesson Plan ID.
3. Access to documents is restricted based on the User's role and institution.
4. Users cannot change their own `role_id` or `institution_id`.
5. All timestamps must be server-generated.

## The "Dirty Dozen" Payloads (Deny Cases)
1. **Self-Promotion**: Faculty user trying to update their own `role_id` to 'Super Admin'.
2. **Cross-Institution Snoop**: User from Institution A trying to read a Course from Institution B.
3. **Ghost Field Update**: Updating a Course with an extra `isVerified: true` hidden field.
4. **ID Poisoning**: Creating a course with a 1MB string as a ID.
5. **Orphaned Lesson Plan**: Creating a Lesson Plan for a non-existent Course ID.
6. **Future-Date Hijack**: Setting `created_at` to a date in 2030.
7. **Role Spoofing**: Setting `role_id` during registration without admin level.
8. **PII Leak**: Unauthorized 'get' on a user's private info.
9. **State Shortcut**: Moving a Lesson Plan from 'Draft' to 'Approved' without HOD reviewer ID.
10. **Shadow Versioning**: Creating a Document Version without incrementing the counter.
11. **Resource Exhaustion**: Sending an array of 10,000 Topic IDs in a course update.
12. **Unverified Email**: Writing data with an auth token where `email_verified` is false.

## The Test Runner
(Tests would be implemented in `firestore.rules.test.ts` focusing on these payloads.)
