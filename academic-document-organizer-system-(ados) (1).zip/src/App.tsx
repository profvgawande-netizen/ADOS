import React, { useState, useEffect } from 'react';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import { 
  LayoutDashboard, 
  BookOpen, 
  Calendar, 
  FileText, 
  Bot, 
  Settings, 
  LogOut, 
  Plus, 
  Download, 
  Search, 
  Upload, 
  Trash2,
  ChevronRight,
  MoreVertical,
  Clock,
  CheckCircle2,
  AlertCircle,
  FileBadge
} from 'lucide-react';
import { animate, motion, AnimatePresence } from 'motion/react';
import axios from 'axios';
import ReactMarkdown from 'react-markdown';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { Toaster, toast } from 'react-hot-toast';
import { aiService } from './services/aiService';

// --- UTILS ---
function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// --- COMPONENTS ---

const Button = ({ className, variant = 'primary', ...props }: any) => {
  const variants: any = {
    primary: 'bg-primary-700 text-white hover:bg-primary-900 shadow-sm',
    secondary: 'bg-white text-neutral-900 border border-neutral-300 hover:bg-neutral-100 shadow-sm',
    danger: 'bg-danger text-white hover:opacity-90 shadow-sm',
    ghost: 'bg-transparent text-neutral-700 hover:bg-neutral-200',
  };
  return (
    <button 
      className={cn(
        'px-4 py-2 rounded-md font-medium transition-all active:scale-95 disabled:opacity-50 disabled:pointer-events-none flex items-center justify-center gap-2',
        variants[variant],
        className
      )}
      {...props}
    />
  );
};

const Card = ({ className, children }: any) => (
  <div className={cn('bg-white rounded-lg border border-neutral-200 shadow-sm overflow-hidden', className)}>
    {children}
  </div>
);

const Input = ({ className, ...props }: any) => (
  <input 
    className={cn(
      'w-full px-3 py-2 rounded-md border border-neutral-300 focus:outline-none focus:ring-2 focus:ring-primary-500 transition-all',
      className
    )}
    {...props}
  />
);

const Badge = ({ variant = 'info', children }: any) => {
  const variants: any = {
    success: 'bg-success/10 text-success border-success/20',
    warning: 'bg-warning/10 text-warning border-warning/20',
    danger: 'bg-danger/10 text-danger border-danger/20',
    info: 'bg-info/10 text-info border-info/20',
  };
  return (
    <span className={cn('px-2 py-0.5 rounded-full text-xs font-semibold border', variants[variant])}>
      {children}
    </span>
  );
};

// --- VIEWS ---

const LoginView = ({ onLogin }: any) => {
  const [email, setEmail] = useState('admin@ados.edu');
  const [password, setPassword] = useState('password123');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      const res = await axios.post('/api/v1/auth/login', { email, password });
      localStorage.setItem('token', res.data.access_token);
      onLogin(res.data.user);
    } catch (err: any) {
      setError(err.response?.data?.message || 'Login failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-neutral-100 p-4">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md"
      >
        <Card className="p-8">
          <div className="flex flex-col items-center mb-8">
            <div className="w-16 h-16 bg-primary-700 rounded-xl flex items-center justify-center text-white mb-4 shadow-lg">
              <BookOpen size={32} />
            </div>
            <h1 className="text-2xl font-bold text-primary-900">ADOS</h1>
            <p className="text-neutral-500 text-center">Academic Document Organizer System</p>
          </div>
          
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-1">Institutional Email</label>
              <Input type="email" value={email} onChange={(e: any) => setEmail(e.target.value)} required />
            </div>
            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-1">Password</label>
              <Input type="password" value={password} onChange={(e: any) => setPassword(e.target.value)} required />
            </div>
            {error && <p className="text-danger text-sm">{error}</p>}
            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? 'Authenticating...' : 'Sign In'}
            </Button>
          </form>
          
          <div className="mt-6 pt-6 border-t border-neutral-100 text-center">
            <a href="#" className="text-sm text-primary-700 hover:underline">Forgot password?</a>
          </div>
        </Card>
        <p className="text-center text-neutral-400 text-xs mt-8">© 2026 Academic Document Organizer System. v1.0.0</p>
      </motion.div>
    </div>
  );
};

const DashboardView = ({ user, setView }: any) => {
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const res = await axios.get('/api/v1/dashboard/stats', {
          headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
        });
        setStats(res.data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchStats();
  }, []);

  const statItems = [
    { label: 'Courses Assigned', value: stats?.total_courses || 0, icon: BookOpen, color: 'text-primary-700' },
    { label: 'Lesson Plans', value: stats?.total_lesson_plans || 0, icon: Calendar, color: 'text-success' },
    { label: 'Pending Approvals', value: stats?.pending_approvals || 0, icon: Clock, color: 'text-warning' },
    { label: 'AI Generated Docs', value: stats?.ai_generated || 0, icon: Bot, color: 'text-info' },
  ];

  return (
    <div className="space-y-8">
      <header className="flex justify-between items-end">
        <div>
          <h1 className="text-3xl font-bold text-neutral-900 tracking-tight">Welcome, {user.name}</h1>
          <p className="text-neutral-500">Here's your academic overview for the current semester.</p>
        </div>
        <Button onClick={() => setView('lesson-generator')}>
          <Plus size={18} /> New Lesson Plan
        </Button>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {statItems.map((item, i) => (
          <Card key={i} className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm text-neutral-500 mb-1">{item.label}</p>
                <p className="text-3xl font-bold">{loading ? '...' : item.value}</p>
              </div>
              <div className={cn('p-2 rounded-lg bg-neutral-100', item.color.replace('text', 'text'))}>
                <item.icon size={24} className={item.color} />
              </div>
            </div>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <Card className="lg:col-span-2">
          <div className="p-6 border-b border-neutral-100 flex justify-between items-center">
            <h3 className="font-bold">My Courses</h3>
            <Button variant="ghost" className="text-xs">View All</Button>
          </div>
          <div className="p-6">
            <div className="space-y-4">
              {[1, 2, 3].map(i => (
                <div key={i} className="flex items-center justify-between p-4 rounded-lg bg-neutral-50 border border-neutral-100">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded bg-primary-100 flex items-center justify-center text-primary-700">
                      <BookOpen size={20} />
                    </div>
                    <div>
                      <h4 className="font-semibold text-neutral-800">Advanced Software Engineering</h4>
                      <p className="text-xs text-neutral-500">CSE-301 • Sem V • 4 Credits</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-6">
                    <div className="text-right">
                      <p className="text-xs text-neutral-500 mb-1">Completion</p>
                      <div className="w-32 h-2 bg-neutral-200 rounded-full overflow-hidden">
                        <div className="h-full bg-success" style={{ width: '65%' }}></div>
                      </div>
                    </div>
                    <Badge variant="success">65%</Badge>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </Card>

        <Card>
          <div className="p-6 border-b border-neutral-100">
            <h3 className="font-bold">AI Quick Tools</h3>
          </div>
          <div className="p-6 grid grid-cols-2 gap-4">
            {[
              { label: 'Lecture Notes', icon: Bot },
              { label: 'MCQs', icon: Plus },
              { label: 'Assignment', icon: FileText },
              { label: 'Lab Manual', icon: BookOpen },
              { label: 'Rubrics', icon: FileBadge },
              { label: 'Syllabus', icon: Search },
            ].map((tool, i) => (
              <button 
                key={i} 
                onClick={() => setView('ai-assistant')}
                className="flex flex-col items-center justify-center p-4 rounded-lg border border-neutral-100 hover:bg-primary-50 hover:border-primary-200 transition-all group"
              >
                <tool.icon size={24} className="text-neutral-400 group-hover:text-primary-700 mb-2" />
                <span className="text-xs font-medium text-neutral-600 group-hover:text-primary-900">{tool.label}</span>
              </button>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
};

const LessonPlanGeneratorView = () => {
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);
  
  const [formData, setFormData] = useState({
    course_id: '',
    start_date: '2026-06-08',
    end_date: '2026-10-03',
    class_days: ['monday', 'tuesday', 'wednesday'],
    exclude_event_types: ['Holiday', 'Exam']
  });

  const [courses, setCourses] = useState<any[]>([]);
  const [topicSource, setTopicSource] = useState<'db' | 'repo'>('repo');
  const [repoDocs, setRepoDocs] = useState<any[]>([]);
  const [selectedDocId, setSelectedDocId] = useState<string>('');
  const [templateDocId, setTemplateDocId] = useState<string>('');

  const handleExportPDF = () => {
    if (!result || !result.items) return;
    
    const doc = new jsPDF();
    const courseName = result.course_name || 'Course';
    
    // Add Border
    doc.setDrawColor(43, 80, 155); // primary-700
    doc.setLineWidth(1);
    doc.rect(5, 5, 200, 287);
    
    // Header
    doc.setFontSize(22);
    doc.setTextColor(43, 80, 155);
    doc.text('ADOS', 105, 20, { align: 'center' });
    
    doc.setFontSize(10);
    doc.setTextColor(100);
    doc.text('Academic Document Organizer System', 105, 26, { align: 'center' });
    
    // Title
    doc.setFontSize(16);
    doc.setTextColor(33, 33, 33);
    doc.text('TEACHING SCHEDULE (LESSON PLAN)', 105, 40, { align: 'center' });
    
    // Details
    doc.setFontSize(10);
    doc.setTextColor(50);
    doc.setFont('helvetica', 'bold');
    doc.text('Course:', 20, 55);
    doc.setFont('helvetica', 'normal');
    doc.text(`${courseName}`, 45, 55);
    
    doc.setFont('helvetica', 'bold');
    doc.text('Faculty:', 20, 62);
    doc.setFont('helvetica', 'normal');
    doc.text(`Test Faculty`, 45, 62); // Hardcoded for now as per user identity
    
    doc.setFont('helvetica', 'bold');
    doc.text('Semester:', 140, 55);
    doc.setFont('helvetica', 'normal');
    doc.text('July - Dec 2026', 165, 55);
    
    doc.setFont('helvetica', 'bold');
    doc.text('Duration:', 140, 62);
    doc.setFont('helvetica', 'normal');
    doc.text(`${formData.start_date} to ${formData.end_date}`, 165, 62);
    
    // Line separator
    doc.setDrawColor(200);
    doc.line(14, 70, 196, 70);

    // Table
    const tableData = result.items.map((item: any) => [
      item.sr_no,
      item.planned_date,
      item.planned_day.substring(0, 3).toUpperCase(),
      item.topic,
      'Planned'
    ]);

    autoTable(doc, {
      startY: 75,
      head: [['Sr No', 'Planned Date', 'Day', 'Topic Details', 'Status']],
      body: tableData,
      theme: 'striped',
      headStyles: { 
        fillColor: [43, 80, 155], 
        textColor: 255, 
        fontSize: 10,
        halign: 'center'
      },
      columnStyles: {
        0: { halign: 'center', cellWidth: 15 },
        1: { halign: 'center', cellWidth: 30 },
        2: { halign: 'center', cellWidth: 20 },
        3: { halign: 'left' },
        4: { halign: 'center', cellWidth: 25 }
      },
      styles: { fontSize: 9, cellPadding: 3 },
      alternateRowStyles: { fillColor: [245, 248, 255] }
    });

    // Footer
    const pageCount = (doc as any).internal.getNumberOfPages();
    for (let i = 1; i <= pageCount; i++) {
      doc.setPage(i);
      doc.setFontSize(8);
      doc.setTextColor(150);
      doc.text(`Generated on ${new Date().toLocaleDateString()} via ADOS AI System`, 14, 285);
      doc.text(`Page ${i} of ${pageCount}`, 196, 285, { align: 'right' });
    }

    const fileName = `LessonPlan_${courseName.replace(/\s+/g, '_')}.pdf`;
    doc.save(fileName);
  };

  useEffect(() => {
    const fetchCoursesAndDocs = async () => {
      try {
        const [courseRes, docRes] = await Promise.all([
          axios.get('/api/v1/courses', {
            headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
          }),
          axios.get('/api/v1/documents', {
            headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
          })
        ]);
        
        const cData = courseRes.data.data || [];
        setCourses(cData);
        if (cData.length > 0) {
          setFormData(prev => ({ ...prev, course_id: cData[0].id }));
        }

        const dData = docRes.data.data || [];
        setRepoDocs(dData);
        if (dData.length > 0) {
          setSelectedDocId(dData[0].id);
        }
      } catch (err) {
        console.error(err);
      }
    };
    fetchCoursesAndDocs();
  }, []);

  const handleGenerate = async () => {
    if (!formData.course_id) return toast.error("Please select a course");
    if (!selectedDocId) return toast.error("Please select a syllabus file");
    if (formData.class_days.length === 0) return toast.error("Please select at least one teaching day");

    setLoading(true);
    try {
      // 1. Get Context from Backend
      const contextRes = await axios.get('/api/v1/lesson-plans/prepare-context', {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
        params: { 
          ...formData, 
          syllabus_doc_id: selectedDocId,
          template_doc_id: templateDocId
        }
      });

      const { availableDates, syllabusText, templateText, courseName } = contextRes.data;

      // 2. Generate with AI in Frontend
      const prompt = `You are an expert academic planner. Your task is to generate a detailed Lesson Plan by mapping topics from a syllabus to available teaching dates.

COURSE: ${courseName}
AVAILABLE TEACHING DATES: ${JSON.stringify(availableDates)}

SYLLABUS CONTENT:
"${syllabusText.substring(0, 15000)}"

${templateText ? `FOLLOW THIS TEMPLATE/FORMAT:
"${templateText.substring(0, 3000)}"` : "DEFAULT BEHAVIOR: Extract chapters and sub-topics from the syllabus and map them sequentially to dates."}

STRICT CONSTRAINTS:
1. TOPIC ACCURACY: You must use the EXACT topic names, chapter titles, and sub-headings as they appear in the SYLLABUS CONTENT. Do not summarize or rename them unless necessary for brevity in the table.
2. SEQUENTIAL MAPPING: Map the topics in the exact order they appear in the syllabus.
3. COMPLETE COVERAGE: Ensure every major chapter/module from the syllabus is represented in the plan.
4. DATE MATCHING: Use ONLY the provided dates. Each date must have at least one topic.
5. IF TOPICS > DATES: Group closely related sub-topics into a single date.
6. IF DATES > TOPICS: Allocate more time for complex topics or add "Revision" / "Case Study" sessions for major modules at the end of sections.
7. OUTPUT FORMAT: Return a JSON array of objects.
   Each object MUST have: sr_no (number), planned_date (string), planned_day (string), topic (string).`;

      const aiResponse = await aiService.generateJSON(prompt, {
        type: "array",
        items: {
          type: "object",
          properties: {
            sr_no: { type: "number" },
            planned_date: { type: "string" },
            planned_day: { type: "string" },
            topic: { type: "string" }
          },
          required: ["sr_no", "planned_date", "planned_day", "topic"]
        }
      });

      const items = Array.isArray(aiResponse) ? aiResponse : [];
      if (items.length === 0) throw new Error("AI failed to generate lesson plan items.");

      // 3. Save to Backend
      const saveRes = await axios.post('/api/v1/lesson-plans/save', {
        course_id: formData.course_id,
        start_date: formData.start_date,
        end_date: formData.end_date,
        items,
        title: "AI Generated Plan"
      }, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });

      setResult(saveRes.data);
      setStep(2);
      toast.success("Lesson plan generated and saved!");
    } catch (err: any) {
      console.error("Generation error:", err);
      toast.error(err.response?.data?.message || err.message || 'Generation failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8">
      <header>
        <h1 className="text-2xl font-bold text-neutral-900">Lesson Plan Generator</h1>
        <p className="text-neutral-500">Automate your date-wise teaching schedule based on academic calendar.</p>
      </header>

      {step === 1 ? (
        <Card className="p-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-neutral-700 mb-2">Select Course</label>
                <select 
                  className="w-full px-3 py-2 rounded-md border border-neutral-300 focus:outline-none focus:ring-2 focus:ring-primary-500"
                  value={formData.course_id}
                  onChange={(e) => setFormData({ ...formData, course_id: e.target.value })}
                >
                  {courses?.map(c => <option key={c.id} value={c.id}>{c.course_name} ({c.course_code})</option>)}
                  {(!courses || courses.length === 0) && <option>No courses found</option>}
                </select>
              </div>

              <div className="animate-in fade-in slide-in-from-top-4 duration-300 space-y-4 shadow-sm border border-primary-100 p-4 rounded-lg bg-primary-50/30">
                <div>
                  <label className="block text-xs font-semibold text-primary-900 uppercase tracking-wider mb-2">Subject Syllabus File</label>
                  <select 
                    className="w-full px-3 py-2 rounded-md border border-neutral-300 focus:outline-none focus:ring-2 focus:ring-primary-500 bg-white"
                    value={selectedDocId}
                    onChange={(e) => setSelectedDocId(e.target.value)}
                  >
                    <option value="">-- Select Syllabus --</option>
                    {repoDocs?.map(d => <option key={d.id} value={d.id}>{d.document_title}</option>)}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-primary-900 uppercase tracking-wider mb-2">Output Format Template (Optional)</label>
                  <select 
                    className="w-full px-3 py-2 rounded-md border border-neutral-300 focus:outline-none focus:ring-2 focus:ring-primary-500 bg-white"
                    value={templateDocId}
                    onChange={(e) => setTemplateDocId(e.target.value)}
                  >
                    <option value="">-- Default Format --</option>
                    {repoDocs?.map(d => <option key={d.id} value={d.id}>{d.document_title}</option>)}
                  </select>
                  <p className="mt-2 text-[10px] text-neutral-500 italic">Select a file that contains the desired layout or format instructions.</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-neutral-700 mb-2">Start Date</label>
                  <Input type="date" value={formData.start_date} onChange={(e: any) => setFormData({ ...formData, start_date: e.target.value })} />
                </div>
                <div>
                  <label className="block text-sm font-medium text-neutral-700 mb-2">End Date</label>
                  <Input type="date" value={formData.end_date} onChange={(e: any) => setFormData({ ...formData, end_date: e.target.value })} />
                </div>
              </div>
            </div>
            
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-neutral-700 mb-2">Weekly Class Days</label>
                <div className="flex flex-wrap gap-2">
                  {['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'].map(day => (
                    <button 
                      key={day}
                      onClick={() => {
                        const low = day.toLowerCase();
                        const next = formData.class_days.includes(low) 
                          ? formData.class_days.filter(d => d !== low)
                          : [...formData.class_days, low];
                        setFormData({ ...formData, class_days: next });
                      }}
                      className={cn(
                        "px-3 py-1 rounded-full border text-sm transition-all",
                        formData.class_days.includes(day.toLowerCase()) 
                          ? "bg-primary-700 text-white border-primary-700" 
                          : "bg-white text-neutral-600 border-neutral-300 hover:border-primary-500"
                      )}
                    >
                      {day.substring(0, 3)}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-neutral-700 mb-2">Calendar Exclusions</label>
                <div className="flex flex-wrap gap-2">
                  {['Holiday', 'Exam', 'Vacation', 'Submission'].map(type => (
                    <button 
                      key={type}
                      onClick={() => {
                        const next = formData.exclude_event_types.includes(type)
                          ? formData.exclude_event_types.filter(t => t !== type)
                          : [...formData.exclude_event_types, type];
                        setFormData({ ...formData, exclude_event_types: next });
                      }}
                      className={cn(
                        "px-3 py-1 rounded-full border text-sm transition-all",
                        formData.exclude_event_types.includes(type)
                          ? "bg-primary-700 text-white border-primary-700"
                          : "bg-white text-neutral-600 border-neutral-300 hover:border-primary-500"
                      )}
                    >
                      {type}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
          
          <div className="pt-6 border-t border-neutral-100 flex justify-end">
            <Button onClick={handleGenerate} disabled={loading || !formData.course_id}>
              {loading ? 'Generating...' : 'Generate Lesson Plan'}
            </Button>
          </div>
        </Card>
      ) : (
        <AnimatePresence>
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-6"
          >
            <div className="flex justify-between items-center">
              <Button variant="ghost" onClick={() => setStep(1)}>← Back to Setup</Button>
              <div className="flex gap-2">
                <Button variant="secondary" onClick={handleExportPDF}><Download size={16} /> Export PDF</Button>
                <Button variant="primary">Submit for Approval</Button>
              </div>
            </div>

            <Card>
              <div className="p-6 border-b border-neutral-100 bg-neutral-50">
                <div className="flex justify-between items-center">
                  <h3 className="font-bold text-lg">{result.course_name || 'Lesson Plan Details'}</h3>
                  <Badge variant="success">{result.status.toUpperCase()}</Badge>
                </div>
                <div className="mt-2 text-sm text-neutral-500 flex gap-4">
                  <span>Topics: {result.total_topics}</span>
                  <span>Slots: {result.available_slots}</span>
                  <span>ID: #{result.lesson_plan_id}</span>
                </div>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-neutral-50 border-b border-neutral-100 text-neutral-600 font-medium">
                    <tr>
                      <th className="px-6 py-3 text-left">Sr No</th>
                      <th className="px-6 py-3 text-left">Date</th>
                      <th className="px-6 py-3 text-left">Day</th>
                      <th className="px-6 py-3 text-left">Topic Title</th>
                      <th className="px-6 py-3 text-left">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-neutral-100">
                    {result?.items?.map((item: any) => (
                      <tr key={item.sr_no} className="hover:bg-neutral-50">
                        <td className="px-6 py-4">{item.sr_no}</td>
                        <td className="px-6 py-4 font-mono">{item.planned_date}</td>
                        <td className="px-6 py-4 uppercase text-xs">{item.planned_day}</td>
                        <td className="px-6 py-4 font-medium">{item.topic}</td>
                        <td className="px-6 py-4"><Badge variant="info">Planned</Badge></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>
          </motion.div>
        </AnimatePresence>
      )}
    </div>
  );
};

const AIAssistantView = () => {
  const [taskType, setTaskType] = useState('lecture_notes');
  const [loading, setLoading] = useState(false);
  const [output, setOutput] = useState('');
  const [formData, setFormData] = useState({
    course_id: '',
    topic_id: '',
    difficulty_level: 'undergraduate',
    custom_instruction: ''
  });

  const [courses, setCourses] = useState<any[]>([]);
  const [topics, setTopics] = useState<any[]>([]);

  useEffect(() => {
    const fetchCourses = async () => {
      try {
        const res = await axios.get('/api/v1/courses', {
          headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
        });
        const data = res.data.data || [];
        setCourses(data);
        if (data.length > 0) setFormData(prev => ({ ...prev, course_id: data[0].id }));
      } catch (err) { console.error(err); }
    };
    fetchCourses();
  }, []);

  useEffect(() => {
    if (!formData.course_id) return;
    const fetchTopics = async () => {
      try {
        const res = await axios.get(`/api/v1/topics?course_id=${formData.course_id}`, {
          headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
        });
        const data = res.data.data || [];
        setTopics(data);
        if (data.length > 0) setFormData(prev => ({ ...prev, topic_id: data[0].id }));
      } catch (err) { console.error(err); }
    };
    fetchTopics();
  }, [formData.course_id]);

  const handleGenerate = async () => {
    setLoading(true);
    try {
      const course = courses.find(c => c.id === formData.course_id);
      const topic = topics.find(t => t.id === formData.topic_id);

      const result = await aiService.generate(taskType, {
        course_name: course?.course_name || "N/A",
        course_code: course?.course_code || "N/A",
        topic_title: topic?.topic_title || "General",
        bloom_level: topic?.bloom_level || "Understand",
        difficulty_level: formData.difficulty_level,
        count: 5,
        custom_instruction: formData.custom_instruction,
        output_format: "detailed markdown"
      });

      setOutput(typeof result === 'string' ? result : JSON.stringify(result, null, 2));
      toast.success("Content generated!");
    } catch (err: any) {
      console.error("AI assistant error:", err);
      toast.error('AI Generation failed: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-8">
      <div className="space-y-6">
        <header>
          <h1 className="text-2xl font-bold text-neutral-900">AI Teaching Assistant</h1>
          <p className="text-neutral-500">Generate high-quality academic content in seconds.</p>
        </header>

        <Card className="p-6 space-y-6">
          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-2">Content Type</label>
            <select 
              className="w-full px-3 py-2 rounded-md border border-neutral-300 focus:outline-none"
              value={taskType}
              onChange={(e) => setTaskType(e.target.value)}
            >
              <option value="lecture_notes">Lecture Notes</option>
              <option value="mcq">MCQ Quiz</option>
              <option value="assignment">Assignment</option>
              <option value="lab_manual">Lab Manual</option>
              <option value="rubric">Assessment Rubric</option>
              <option value="syllabus_summary">Syllabus Summary</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-2">Course</label>
            <select 
              className="w-full px-3 py-2 rounded-md border border-neutral-300 focus:outline-none"
              value={formData.course_id}
              onChange={(e) => setFormData({ ...formData, course_id: e.target.value })}
            >
              {courses?.map(c => <option key={c.id} value={c.id}>{c.course_name}</option>)}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-2">Topic</label>
            <select 
              className="w-full px-3 py-2 rounded-md border border-neutral-300 focus:outline-none"
              value={formData.topic_id}
              onChange={(e) => setFormData({ ...formData, topic_id: e.target.value })}
            >
              {topics?.map(t => <option key={t.id} value={t.id}>{t.topic_title}</option>)}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-2">Instructions (Optional)</label>
            <textarea 
              className="w-full px-3 py-2 rounded-md border border-neutral-300 focus:outline-none h-24 text-sm"
              placeholder="e.g. Include real-world case studies from India..."
              value={formData.custom_instruction}
              onChange={(e) => setFormData({ ...formData, custom_instruction: e.target.value })}
            />
          </div>

          <Button className="w-full h-12" onClick={handleGenerate} disabled={loading}>
            {loading ? <Spinner /> : <><Bot size={18} /> Generate Content</>}
          </Button>
        </Card>
      </div>

      <Card className="lg:col-span-2 min-h-[600px] flex flex-col">
        <div className="p-4 border-b border-neutral-100 flex justify-between items-center bg-neutral-50">
          <h3 className="font-bold flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-success"></div>
            AI Generator Preview
          </h3>
          <div className="flex gap-2">
            <Button variant="ghost" className="h-8 py-0 px-2" onClick={() => navigator.clipboard.writeText(output)}>Copy</Button>
            <Button variant="ghost" className="h-8 py-0 px-2">Save</Button>
          </div>
        </div>
        <div className="flex-1 p-8 overflow-y-auto bg-neutral-50/30">
          {!output && !loading && (
            <div className="h-full flex flex-col items-center justify-center text-neutral-400">
              <Bot size={48} className="mb-4 opacity-20" />
              <p>Configure options and click generate to start.</p>
            </div>
          )}
          {loading && (
            <div className="h-full flex flex-col items-center justify-center space-y-4">
              <Spinner className="w-12 h-12 text-primary-700" />
              <div className="flex flex-col items-center">
                <p className="font-medium text-primary-900">Gemini 2.0 is thinking...</p>
                <p className="text-sm text-neutral-500">Generating high-quality academic content </p>
              </div>
            </div>
          )}
          {output && !loading && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="markdown-body">
              <ReactMarkdown>{output}</ReactMarkdown>
            </motion.div>
          )}
        </div>
      </Card>
    </div>
  );
};

const AcademicRepositoryView = () => {
  const [docs, setDocs] = useState<any[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  const fetchDocs = async () => {
    try {
      const res = await axios.get('/api/v1/documents', {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      setDocs(res.data.data);
    } catch (err) { console.error(err); }
    finally { setLoading(false); }
  };

  useEffect(() => {
    fetchDocs();
  }, []);

  const filteredDocs = docs?.filter(doc => 
    doc.document_title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    doc.document_type.toLowerCase().includes(searchQuery.toLowerCase())
  ) || [];

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setUploading(true);
    const formData = new FormData();
    formData.append('file', file);
    formData.append('document_type', 'Syllabus'); // Default type

    try {
      await axios.post('/api/v1/documents/upload', formData, {
        headers: { 
          'Content-Type': 'multipart/form-data',
          Authorization: `Bearer ${localStorage.getItem('token')}` 
        }
      });
      await fetchDocs();
    } catch (err) {
      console.error("Upload failed", err);
      alert('Upload failed. Please try again.');
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleDelete = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!confirm('Are you sure you want to delete this document?')) return;

    try {
      await axios.delete(`/api/v1/documents/${id}`, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      toast.success('Document deleted successfully');
      await fetchDocs();
    } catch (err) {
      console.error("Delete failed", err);
      toast.error('Failed to delete document');
    }
  };

  return (
    <div className="space-y-8">
      <header className="flex justify-between items-end">
        <div>
          <h1 className="text-2xl font-bold text-neutral-900">Academic Repository</h1>
          <p className="text-neutral-500">Store and manage institutional documents, syllabus, and templates.</p>
        </div>
        <div className="flex gap-2">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400" size={16} />
            <Input 
              placeholder="Search documents..." 
              className="w-64 pl-10" 
              value={searchQuery}
              onChange={(e: any) => setSearchQuery(e.target.value)}
            />
          </div>
          <input 
            type="file" 
            ref={fileInputRef} 
            className="hidden" 
            onChange={handleFileUpload}
          />
          <Button 
            variant="primary" 
            onClick={() => fileInputRef.current?.click()}
            disabled={uploading}
          >
            {uploading ? <Spinner /> : <><Upload size={18} /> Upload File</>}
          </Button>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredDocs.length === 0 && !loading && (
          <div className="col-span-full py-12 flex flex-col items-center justify-center text-neutral-400 bg-white rounded-lg border border-dashed border-neutral-300">
            <Search size={48} className="mb-4 opacity-20" />
            <p>No documents found matching your criteria.</p>
          </div>
        )}
        {filteredDocs.map((doc, i) => (
          <Card key={doc.id || i} className="hover:border-primary-300 transition-all group">
            <div className="p-6">
              <div className="flex justify-between items-start mb-4">
                <div className="p-3 bg-neutral-100 rounded-lg group-hover:bg-primary-100 transition-all">
                  <FileText className="text-neutral-500 group-hover:text-primary-700" />
                </div>
                <div className="flex gap-1">
                  <button 
                    onClick={(e) => handleDelete(doc.id, e)}
                    className="p-1.5 text-danger bg-danger/5 hover:bg-danger/20 rounded-md transition-all shadow-sm flex items-center justify-center"
                    title="Delete Document"
                  >
                    <Trash2 size={16} />
                  </button>
                  <button className="p-1.5 text-neutral-400 hover:text-neutral-600 rounded-md"><MoreVertical size={18} /></button>
                </div>
              </div>
              <h4 className="font-bold text-neutral-900 mb-1 line-clamp-1">{doc.document_title}</h4>
              <p className="text-xs text-neutral-500 flex items-center gap-2">
                <Badge variant="info">{doc.document_type}</Badge>
                <span>{(doc.file_size / 1024 / 1024).toFixed(2)} MB</span>
              </p>
              <div className="mt-6 pt-4 border-t border-neutral-100 flex justify-between items-center text-xs text-neutral-400">
                <span>{new Date(doc.created_at).toLocaleDateString()}</span>
                <span className="flex items-center gap-1"><Download size={12} /> 12 Downloads</span>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
};

const ApprovalWorkflowView = () => {
  const [approvals, setApprovals] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetch = async () => {
      try {
        const res = await axios.get('/api/v1/approvals', {
          headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
        });
        setApprovals(res.data.data);
      } catch (err) { console.error(err); }
      finally { setLoading(false); }
    };
    fetch();
  }, []);

  const handleAction = async (id: number, action: string) => {
    try {
      await axios.post(`/api/v1/approvals/${id}/${action}`, {}, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      setApprovals(prev => prev.map(a => a.id === id ? { ...a, status: action === 'approve' ? 'Approved' : 'Rejected' } : a));
    } catch (err) { alert('Action failed'); }
  };

  return (
    <div className="space-y-8">
      <header>
        <h1 className="text-2xl font-bold text-neutral-900">Approval Workflow</h1>
        <p className="text-neutral-500">Review and approve academic documents submitted by faculty.</p>
      </header>
      <Card>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-neutral-50 border-b border-neutral-100 text-neutral-600 font-medium">
              <tr>
                <th className="px-6 py-3 text-left">Document</th>
                <th className="px-6 py-3 text-left">Submitted By</th>
                <th className="px-6 py-3 text-left">Date</th>
                <th className="px-6 py-3 text-left">Status</th>
                <th className="px-6 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-100">
              {approvals?.map((a: any) => (
                <tr key={a.id} className="hover:bg-neutral-50 font-sans">
                  <td className="px-6 py-4 font-medium">{a.document_title}</td>
                  <td className="px-6 py-4">{a.submitted_by_name}</td>
                  <td className="px-6 py-4 text-neutral-500">{new Date(a.submitted_at).toLocaleDateString()}</td>
                  <td className="px-6 py-4">
                    <Badge variant={a.status === 'Approved' ? 'success' : a.status === 'Rejected' ? 'danger' : 'warning'}>
                      {a.status}
                    </Badge>
                  </td>
                  <td className="px-6 py-4 text-right">
                    {a.status === 'Submitted' && (
                      <div className="flex justify-end gap-2">
                        <Button variant="secondary" className="px-2 py-1 text-xs" onClick={() => handleAction(a.id, 'reject')}>Reject</Button>
                        <Button variant="primary" className="px-2 py-1 text-xs" onClick={() => handleAction(a.id, 'approve')}>Approve</Button>
                      </div>
                    )}
                  </td>
                </tr>
              ))}
              {(!approvals || approvals.length === 0) && !loading && (
                <tr><td colSpan={5} className="px-6 py-8 text-center text-neutral-400">No pending approvals found.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
};

const ReportsView = () => {
  const [data, setData] = useState<any[]>([]);
  
  useEffect(() => {
    const fetch = async () => {
      try {
        const res = await axios.get('/api/v1/reports/faculty-workload', {
          headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
        });
        setData(res.data.data);
      } catch (err) { console.error(err); }
    };
    fetch();
  }, []);

  return (
    <div className="space-y-8">
      <header>
        <h1 className="text-2xl font-bold text-neutral-900">Academic Reports</h1>
        <p className="text-neutral-500">Analytics and insights into academic activities and workload.</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <Card className="p-6">
          <h3 className="font-bold mb-6">Faculty Workload (Classes/Week)</h3>
          <div className="space-y-6">
            {data?.map((item, i) => (
              <div key={i}>
                <div className="flex justify-between text-sm mb-2">
                  <span className="font-medium text-neutral-700">{item.full_name}</span>
                  <span className="text-neutral-500">{item.classes_count} Classes</span>
                </div>
                <div className="w-full h-3 bg-neutral-100 rounded-full overflow-hidden">
                  <motion.div 
                    initial={{ width: 0 }} 
                    animate={{ width: `${(item.classes_count / 10) * 100}%` }} 
                    className="h-full bg-primary-700"
                  />
                </div>
              </div>
            ))}
          </div>
        </Card>

        <Card className="p-6 flex flex-col items-center justify-center text-center space-y-4">
          <div className="w-20 h-20 bg-primary-100 rounded-full flex items-center justify-center text-primary-700">
            <FileBadge size={40} />
          </div>
          <h3 className="font-bold text-xl">Accreditation Ready</h3>
          <p className="text-neutral-500 text-sm max-w-xs">Your documents are organized and mapped to Course Outcomes (CO) for NBA/NAAC audits.</p>
          <Button variant="secondary">Generate Audit Trail</Button>
        </Card>
      </div>
    </div>
  );
};

const Spinner = ({ className }: any) => (
  <div className={cn("inline-block animate-spin rounded-full border-2 border-solid border-current border-r-transparent align-[-0.125em] motion-reduce:animate-[spin_1.5s_linear_infinite]", className)} role="status">
    <span className="!absolute !-m-px !h-px !w-px !overflow-hidden !whitespace-nowrap !border-0 !p-0 ![clip:rect(0,0,0,0)] italic">Loading...</span>
  </div>
);

// --- MAIN APP ---

export default function App() {
  const [user, setUser] = useState<any>({ id: 'test-admin-id', name: 'Test Admin', full_name: 'Test Administrator', email: 'admin@ados.edu', role_id: '1', role_name: 'Super Admin' });
  const [view, setView] = useState('dashboard'); // dashboard, lesson-generator, ai-assistant, repository
  const [isSidebarOpen, setSidebarOpen] = useState(true);

  // useEffect disabled for test mode bypass
  useEffect(() => {
    // skip checkUser for testing purposes
  }, []);

  // if (!user) return <LoginView onLogin={setUser} />;

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'lesson-generator', label: 'Lesson Plan', icon: Calendar },
    { id: 'ai-assistant', label: 'AI Assistant', icon: Bot },
    { id: 'repository', label: 'Repository', icon: BookOpen },
    { id: 'approvals', label: 'Approvals', icon: CheckCircle2 },
    { id: 'reports', label: 'Reports', icon: FileText },
  ];

  const renderView = () => {
    switch (view) {
      case 'dashboard': return <DashboardView user={user} setView={setView} />;
      case 'lesson-generator': return <LessonPlanGeneratorView />;
      case 'ai-assistant': return <AIAssistantView />;
      case 'repository': return <AcademicRepositoryView />;
      case 'approvals': return <ApprovalWorkflowView />;
      case 'reports': return <ReportsView />;
      default: return <DashboardView user={user} setView={setView} />;
    }
  };

  return (
    <div className="flex h-screen bg-neutral-100 overflow-hidden">
      <Toaster />
      {/* Sidebar */}
      <motion.aside 
        initial={false}
        animate={{ width: isSidebarOpen ? 260 : 80 }}
        className="bg-primary-900 text-white flex flex-col relative z-20"
      >
        <div className="p-6 flex items-center gap-3 border-b border-primary-800 h-16">
          <BookOpen className="text-secondary shrink-0" size={24} />
          {isSidebarOpen && <span className="font-bold text-xl tracking-tight">ADOS</span>}
        </div>

        <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
          {navItems.map(item => (
            <button 
              key={item.id}
              onClick={() => setView(item.id)}
              className={cn(
                "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all group",
                view === item.id ? "bg-primary-700 text-white" : "text-primary-100 hover:bg-primary-800"
              )}
            >
              <item.icon size={20} className={view === item.id ? "text-white" : "text-primary-300 group-hover:text-white"} />
              {isSidebarOpen && <span className="font-medium text-sm">{item.label}</span>}
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-primary-800">
          <button 
            onClick={() => { localStorage.removeItem('token'); setUser(null); }}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-primary-300 hover:bg-danger hover:text-white transition-all group"
          >
            <LogOut size={20} />
            {isSidebarOpen && <span className="font-medium text-sm">Logout</span>}
          </button>
        </div>
      </motion.aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top Header */}
        <header className="h-16 bg-white border-b border-neutral-200 flex items-center justify-between px-8 z-10 shrink-0">
          <button onClick={() => setSidebarOpen(!isSidebarOpen)} className="p-2 -ml-2 text-neutral-400 hover:text-neutral-600 rounded-md">
            <Search size={20} />
          </button>
          
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-3">
              <div className="text-right hidden sm:block">
                <p className="text-sm font-semibold text-neutral-900">{user.full_name}</p>
                <p className="text-xs text-neutral-500 uppercase tracking-wider">{user.role_name || 'Faculty'}</p>
              </div>
              <div className="w-10 h-10 rounded-full bg-neutral-200 border border-neutral-100 flex items-center justify-center font-bold text-neutral-500">
                {user.full_name?.charAt(0)}
              </div>
            </div>
          </div>
        </header>

        {/* Dynamic View Scroll Area */}
        <main className="flex-1 overflow-y-auto">
          <div className="p-8 pb-16">
            <AnimatePresence mode="wait">
              <motion.div
                key={view}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
              >
                {renderView()}
              </motion.div>
            </AnimatePresence>
          </div>
        </main>
      </div>
    </div>
  );
}
