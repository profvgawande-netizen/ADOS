import { initializeApp, getApps } from 'firebase/app';
import { getFirestore, collection, getDocs, doc, setDoc, updateDoc, addDoc, query, where, orderBy, limit, getDoc, getCountFromServer, writeBatch, collectionGroup, deleteDoc } from 'firebase/firestore';
import fs from 'fs';
import path from 'path';

let cachedDbWrapper: any = null;

export async function getDb(): Promise<any> {
  if (cachedDbWrapper) return cachedDbWrapper;

  try {
    const configPath = path.resolve(process.cwd(), 'firebase-applet-config.json');
    if (!fs.existsSync(configPath)) {
      throw new Error(`Firebase config file not found at ${configPath}. Please run set_up_firebase.`);
    }

    const config = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
    console.log(`ADOS: Initializing Firestore using Client SDK (Node). Project: ${config.projectId}`);

    const app = getApps().length === 0 ? initializeApp(config) : getApps()[0];
    const firestore = getFirestore(app, config.firestoreDatabaseId);

    const wrapper = {
      collection: (collectionPath: string) => {
        const collRef = collection(firestore, collectionPath);
        
        const createDocWrapper = (docRef: any) => ({
          get: () => getDoc(docRef),
          set: (data: any) => setDoc(docRef, data),
          update: (data: any) => updateDoc(docRef, data),
          delete: () => deleteDoc(docRef),
          collection: (subPath: string) => wrapper.collection(`${collectionPath}/${docRef.id}/${subPath}`),
          id: docRef.id,
          ref: docRef
        });

        return {
          doc: (id?: string) => {
            const docRef = id ? doc(firestore, collectionPath, id) : doc(collRef);
            return createDocWrapper(docRef);
          },
          get: () => getDocs(collRef),
          add: async (data: any) => {
            const docRef = await addDoc(collRef, data);
            return createDocWrapper(docRef);
          },
          where: (field: string, op: any, value: any) => wrapper._query(query(collRef, where(field, op, value))),
          limit: (n: number) => wrapper._query(query(collRef, limit(n))),
          orderBy: (field: string, dir?: 'asc' | 'desc') => wrapper._query(query(collRef, orderBy(field, dir))),
          count: () => ({ get: () => getCountFromServer(collRef) }),
        };
      },
      collectionGroup: (id: string) => {
        const cgRef = collectionGroup(firestore, id);
        return wrapper._query(cgRef);
      },
      _query: (q: any) => ({
        where: (field: string, op: any, value: any) => wrapper._query(query(q, where(field, op, value))),
        limit: (n: number) => wrapper._query(query(q, limit(n))),
        orderBy: (field: string, dir?: 'asc' | 'desc') => wrapper._query(query(q, orderBy(field, dir))),
        get: () => getDocs(q),
        count: () => ({ get: () => getCountFromServer(q) }),
      }),
      batch: () => {
        const batch = writeBatch(firestore);
        return {
          set: (docWrapper: any, data: any) => {
            if (docWrapper && docWrapper.ref) {
               batch.set(docWrapper.ref, data);
            }
          },
          commit: () => batch.commit()
        };
      },
      raw: firestore
    };

    cachedDbWrapper = wrapper;
    return cachedDbWrapper;
  } catch (err) {
    console.error("ADOS: Error in getDb initialization:", err);
    throw err;
  }
}
