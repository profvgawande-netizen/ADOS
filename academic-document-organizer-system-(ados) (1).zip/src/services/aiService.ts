import { GoogleGenAI, Type } from "@google/genai";

let genAI: GoogleGenAI | null = null;

function getAI() {
  if (!genAI) {
    // In Vite, process.env.GEMINI_API_KEY is available if configured correctly
    // or we can use the pattern from the skill.
    const GEMINI_API_KEY = process.env.GEMINI_API_KEY || "";
    genAI = new GoogleGenAI({ apiKey: GEMINI_API_KEY });
  }
  return genAI;
}

const TASK_PROMPTS: Record<string, string> = {
  "lecture_notes": `
You are an expert academic lecturer. Generate detailed, well-structured lecture notes for the following topic.

Course : {course_name} ({course_code})
Topic : {topic_title}
Bloom : {bloom_level}
Level : {difficulty_level}
Format : {output_format}
Extra : {custom_instruction}

Requirements:
- Start with a short introduction (2-3 sentences)
- Cover core concepts with clear explanations
- Provide 2-3 real-world examples
- End with 3 key takeaways
- Use bullet-point sub-sections for clarity
`,
  "assignment": `
You are an experienced university professor. Create a well-structured assignment for:

Course : {course_name} ({course_code})
Topic : {topic_title}
Level : {difficulty_level}
Extra : {custom_instruction}

Include:
1. Assignment title
2. Objectives (3-4 points)
3. Task description (detailed)
4. Submission guidelines
5. Grading rubric table (Criteria | Excellent | Good | Satisfactory | Poor)
6. References format
`,
  "mcq": `
Generate {count} Multiple Choice Questions (MCQs) for:

Course : {course_name}
Topic : {topic_title}
Difficulty: {difficulty_level}
Bloom : {bloom_level}

Return ONLY valid JSON in this exact format (no extra text):
{
  "questions": [
    {
      "question": "...",
      "options": ["A. ...", "B. ...", "C. ...", "D. ..."],
      "answer": "A",
      "explanation": "..."
    }
  ]
}
`,
  "descriptive_questions": `
Generate {count} descriptive questions for:

Course : {course_name}
Topic : {topic_title}
Difficulty: {difficulty_level}
Marks each: {marks_per_question}

Return ONLY valid JSON:
{
  "questions": [
    {
      "question": "...",
      "marks": {marks_per_question},
      "model_answer": "..."
    }
  ]
}
`,
  "rubric": `
Create a detailed assessment rubric for the following:

Course : {course_name}
Topic/Task : {topic_title}
Level : {difficulty_level}
Extra : {custom_instruction}

Format as a markdown table with columns:
Criteria | Excellent (90-100%) | Good (75-89%) | Satisfactory (60-74%) | Needs Improvement (<60%) | Weight

Include 5-7 assessment criteria relevant to the task.
`,
  "syllabus_summary": `
Summarize the following course syllabus concisely for faculty reference.

Course: {course_name} ({course_code})
Topics covered: {topic_title}
Extra: {custom_instruction}

Provide:
1. One-paragraph course overview
2. Unit-wise topic summary (bullet points per unit)
3. Key skills students will gain
4. Recommended reference books (3-4 standard texts)
5. Suggested teaching strategy
`,
  "project_topics": `
Suggest {count} innovative project topics for final-year students in:

Course : {course_name}
Topic Area: {topic_title}
Level : {difficulty_level}

Return ONLY valid JSON:
{
  "projects": [
    {
      "title": "...",
      "description": "...",
      "tech_stack": ["...", "..."],
      "difficulty": "..."
    }
  ]
}
`,
  "academic_report": `
Draft a formal academic report section for:

Course : {course_name}
Topic : {topic_title}
Purpose : {custom_instruction}

Include:
1. Introduction
2. Objectives
3. Methodology / Approach
4. Findings / Content
5. Conclusion
6. Recommendations

Use formal academic language.
`,
  "question_paper": `
Generate a complete question paper for:

Course : {course_name} ({course_code})
Total Marks : {total_marks}
Duration : {duration}
Difficulty Mix: {difficulty_mix}
Extra : {custom_instruction}

Return ONLY valid JSON:
{
  "sections": [
    {
      "section_title": "Section A - Objective",
      "instructions": "...",
      "questions": [
        {
          "q_no": 1,
          "question": "...",
          "marks": 2,
          "type": "MCQ",
          "answer": "..."
        }
      ]
    }
  ]
}
`
};

export class GeminiAIService {
  async generate(taskType: string, options: any) {
    const template = TASK_PROMPTS[taskType];
    if (!template) {
      throw new Error(`Unknown task type: ${taskType}`);
    }

    let prompt = template;
    for (const [key, value] of Object.entries(options)) {
      prompt = prompt.replace(new RegExp(`{${key}}`, 'g'), String(value));
    }

    const ai = getAI();
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt
    });

    let text = response.text.trim();

    // Clean JSON if needed
    if (["mcq", "descriptive_questions", "project_topics", "question_paper"].includes(taskType)) {
      text = text.replace(/^```json\s*/, '').replace(/\s*```$/, '');
      try {
        return JSON.parse(text);
      } catch (e) {
        console.error("Failed to parse JSON from Gemini:", text);
        return { error: "Failed to parse AI response", raw: text };
      }
    }

    return text;
  }

  async generatePure(prompt: string) {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt
    });
    return response.text.trim();
  }

  async generateJSON(prompt: string, schema: any) {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: schema
      }
    });

    const text = response.text.trim();
    try {
      return JSON.parse(text);
    } catch (e) {
      console.error("Failed to parse AI JSON:", text);
      // Fallback: search for JSON block
      const match = text.match(/\[[\s\S]*\]|\{[\s\S]*\}/);
      if (match) {
        return JSON.parse(match[0]);
      }
      throw e;
    }
  }

  async extractTopics(text: string) {
    const prompt = `
You are an academic syllabus parser. Extract all chapters and topics from the text below.

Rules:
- Identify numbered chapters/units (e.g., Unit 1, Chapter 1, Module 1)
- Extract each topic listed under that chapter
- Infer Bloom's taxonomy level for each topic (Remember/Understand/Apply/Analyze/Evaluate/Create)
- Return ONLY valid JSON in this format:
{
  "chapters": [
    {
      "chapter_no": "CH1",
      "chapter_title": "Introduction to ...",
      "sequence_no": 1,
      "topics": [
        { "title": "Topic name", "bloom_level": "Understand" }
      ]
    }
  ]
}

SYLLABUS TEXT:
${text.substring(0, 10000)}
`;
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt
    });
    let responseText = response.text.trim();
    responseText = responseText.replace(/^```json\s*/, '').replace(/\s*```$/, '');
    return JSON.parse(responseText);
  }

  async extractCalendarEvents(text: string) {
    const prompt = `
You are an academic calendar parser. Extract all calendar events from the text below.

Event types to detect: Holiday, Exam, Vacation, Submission, Teaching, Institutional Event, Practical Exam

Return ONLY valid JSON array:
[
  {
    "event_name": "Republic Day",
    "event_type": "Holiday",
    "start_date": "YYYY-MM-DD",
    "end_date": "YYYY-MM-DD",
    "is_teaching_blocked": true,
    "description": ""
  }
]

Use ISO date format (YYYY-MM-DD).

CALENDAR TEXT:
${text.substring(0, 10000)}
`;
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt
    });
    let responseText = response.text.trim();
    responseText = responseText.replace(/^```json\s*/, '').replace(/\s*```$/, '');
    return JSON.parse(responseText);
  }
}

export const aiService = new GeminiAIService();
